Aplikasi iseng 
semoga bermanfaat :)